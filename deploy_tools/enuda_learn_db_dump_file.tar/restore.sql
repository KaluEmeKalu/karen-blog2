--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.3
-- Dumped by pg_dump version 10.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_user_id_c564eba6_fk;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co;
ALTER TABLE ONLY public.dashboard_studentgroup_students DROP CONSTRAINT dashboard_studentgro_user_id_be02ef48_fk_auth_user;
ALTER TABLE ONLY public.dashboard_studentgroup_banzhuren DROP CONSTRAINT dashboard_studentgro_user_id_8f7a0f47_fk_auth_user;
ALTER TABLE ONLY public.dashboard_studentgroup_students DROP CONSTRAINT dashboard_studentgro_studentgroup_id_2ba55a3e_fk_dashboard;
ALTER TABLE ONLY public.dashboard_studentgroup_banzhuren DROP CONSTRAINT dashboard_studentgro_studentgroup_id_1fd4f0ae_fk_dashboard;
ALTER TABLE ONLY public.dashboard_course_student_groups DROP CONSTRAINT dashboard_course_stu_studentgroup_id_522ba68f_fk_dashboard;
ALTER TABLE ONLY public.dashboard_course_student_groups DROP CONSTRAINT dashboard_course_stu_course_id_684fe305_fk_dashboard;
ALTER TABLE ONLY public.dashboard_course DROP CONSTRAINT dashboard_course_image_id_a15425c4_fk_dashboard_image_id;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm;
DROP INDEX public.django_session_session_key_c0390e0f_like;
DROP INDEX public.django_session_expire_date_a5c62663;
DROP INDEX public.django_admin_log_user_id_c564eba6;
DROP INDEX public.django_admin_log_content_type_id_c4bce8eb;
DROP INDEX public.dashboard_studentgroup_students_user_id_be02ef48;
DROP INDEX public.dashboard_studentgroup_students_studentgroup_id_2ba55a3e;
DROP INDEX public.dashboard_studentgroup_banzhuren_user_id_8f7a0f47;
DROP INDEX public.dashboard_studentgroup_banzhuren_studentgroup_id_1fd4f0ae;
DROP INDEX public.dashboard_course_student_groups_studentgroup_id_522ba68f;
DROP INDEX public.dashboard_course_student_groups_course_id_684fe305;
DROP INDEX public.dashboard_course_slug_8f677be8_like;
DROP INDEX public.dashboard_course_slug_8f677be8;
DROP INDEX public.dashboard_course_image_id_a15425c4;
DROP INDEX public.auth_user_username_6821ab7c_like;
DROP INDEX public.auth_user_user_permissions_user_id_a95ead1b;
DROP INDEX public.auth_user_user_permissions_permission_id_1fbb5f2c;
DROP INDEX public.auth_user_groups_user_id_6a12ed8b;
DROP INDEX public.auth_user_groups_group_id_97559544;
DROP INDEX public.auth_permission_content_type_id_2f476e4b;
DROP INDEX public.auth_group_permissions_permission_id_84c5c92e;
DROP INDEX public.auth_group_permissions_group_id_b120cbf9;
DROP INDEX public.auth_group_name_a6ea08ec_like;
ALTER TABLE ONLY public.django_session DROP CONSTRAINT django_session_pkey;
ALTER TABLE ONLY public.django_migrations DROP CONSTRAINT django_migrations_pkey;
ALTER TABLE ONLY public.django_content_type DROP CONSTRAINT django_content_type_pkey;
ALTER TABLE ONLY public.django_content_type DROP CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_pkey;
ALTER TABLE ONLY public.dashboard_studentgroup_students DROP CONSTRAINT dashboard_studentgroup_students_pkey;
ALTER TABLE ONLY public.dashboard_studentgroup_students DROP CONSTRAINT dashboard_studentgroup_s_studentgroup_id_user_id_2ae3b5cf_uniq;
ALTER TABLE ONLY public.dashboard_studentgroup DROP CONSTRAINT dashboard_studentgroup_pkey;
ALTER TABLE ONLY public.dashboard_studentgroup_banzhuren DROP CONSTRAINT dashboard_studentgroup_banzhuren_pkey;
ALTER TABLE ONLY public.dashboard_studentgroup_banzhuren DROP CONSTRAINT dashboard_studentgroup_b_studentgroup_id_user_id_531c24a4_uniq;
ALTER TABLE ONLY public.dashboard_image DROP CONSTRAINT dashboard_image_pkey;
ALTER TABLE ONLY public.dashboard_course_student_groups DROP CONSTRAINT dashboard_course_student_groups_pkey;
ALTER TABLE ONLY public.dashboard_course_student_groups DROP CONSTRAINT dashboard_course_student_course_id_studentgroup_i_eca8ef8c_uniq;
ALTER TABLE ONLY public.dashboard_course DROP CONSTRAINT dashboard_course_pkey;
ALTER TABLE ONLY public.auth_user DROP CONSTRAINT auth_user_username_key;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_pkey;
ALTER TABLE ONLY public.auth_user DROP CONSTRAINT auth_user_pkey;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_pkey;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_pkey;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq;
ALTER TABLE ONLY public.auth_group DROP CONSTRAINT auth_group_pkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_pkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq;
ALTER TABLE ONLY public.auth_group DROP CONSTRAINT auth_group_name_key;
ALTER TABLE public.django_migrations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_content_type ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_admin_log ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.dashboard_studentgroup_students ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.dashboard_studentgroup_banzhuren ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.dashboard_studentgroup ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.dashboard_image ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.dashboard_course_student_groups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.dashboard_course ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user_user_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user_groups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_permission ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_group_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_group ALTER COLUMN id DROP DEFAULT;
DROP TABLE public.django_session;
DROP SEQUENCE public.django_migrations_id_seq;
DROP TABLE public.django_migrations;
DROP SEQUENCE public.django_content_type_id_seq;
DROP TABLE public.django_content_type;
DROP SEQUENCE public.django_admin_log_id_seq;
DROP TABLE public.django_admin_log;
DROP SEQUENCE public.dashboard_studentgroup_students_id_seq;
DROP TABLE public.dashboard_studentgroup_students;
DROP SEQUENCE public.dashboard_studentgroup_id_seq;
DROP SEQUENCE public.dashboard_studentgroup_banzhuren_id_seq;
DROP TABLE public.dashboard_studentgroup_banzhuren;
DROP TABLE public.dashboard_studentgroup;
DROP SEQUENCE public.dashboard_image_id_seq;
DROP TABLE public.dashboard_image;
DROP SEQUENCE public.dashboard_course_student_groups_id_seq;
DROP TABLE public.dashboard_course_student_groups;
DROP SEQUENCE public.dashboard_course_id_seq;
DROP TABLE public.dashboard_course;
DROP SEQUENCE public.auth_user_user_permissions_id_seq;
DROP TABLE public.auth_user_user_permissions;
DROP SEQUENCE public.auth_user_id_seq;
DROP SEQUENCE public.auth_user_groups_id_seq;
DROP TABLE public.auth_user_groups;
DROP TABLE public.auth_user;
DROP SEQUENCE public.auth_permission_id_seq;
DROP TABLE public.auth_permission;
DROP SEQUENCE public.auth_group_permissions_id_seq;
DROP TABLE public.auth_group_permissions;
DROP SEQUENCE public.auth_group_id_seq;
DROP TABLE public.auth_group;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: kalukalu
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO kalukalu;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: kalukalu
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: kalu
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO kalu;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: kalu
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO kalu;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kalu
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: kalu
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO kalu;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: kalu
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO kalu;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kalu
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: kalu
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO kalu;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: kalu
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO kalu;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kalu
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: kalu
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO kalu;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: kalu
--

CREATE TABLE public.auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO kalu;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: kalu
--

CREATE SEQUENCE public.auth_user_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO kalu;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kalu
--

ALTER SEQUENCE public.auth_user_groups_id_seq OWNED BY public.auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: kalu
--

CREATE SEQUENCE public.auth_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO kalu;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kalu
--

ALTER SEQUENCE public.auth_user_id_seq OWNED BY public.auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: kalu
--

CREATE TABLE public.auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO kalu;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: kalu
--

CREATE SEQUENCE public.auth_user_user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO kalu;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kalu
--

ALTER SEQUENCE public.auth_user_user_permissions_id_seq OWNED BY public.auth_user_user_permissions.id;


--
-- Name: dashboard_course; Type: TABLE; Schema: public; Owner: kalu
--

CREATE TABLE public.dashboard_course (
    id integer NOT NULL,
    name character varying(80),
    "timestamp" timestamp with time zone NOT NULL,
    updated timestamp with time zone,
    slug character varying(50) NOT NULL,
    image_id integer,
    description text,
    brief_description character varying(160),
    tagline character varying(160)
);


ALTER TABLE public.dashboard_course OWNER TO kalu;

--
-- Name: dashboard_course_id_seq; Type: SEQUENCE; Schema: public; Owner: kalu
--

CREATE SEQUENCE public.dashboard_course_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dashboard_course_id_seq OWNER TO kalu;

--
-- Name: dashboard_course_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kalu
--

ALTER SEQUENCE public.dashboard_course_id_seq OWNED BY public.dashboard_course.id;


--
-- Name: dashboard_course_student_groups; Type: TABLE; Schema: public; Owner: kalu
--

CREATE TABLE public.dashboard_course_student_groups (
    id integer NOT NULL,
    course_id integer NOT NULL,
    studentgroup_id integer NOT NULL
);


ALTER TABLE public.dashboard_course_student_groups OWNER TO kalu;

--
-- Name: dashboard_course_student_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: kalu
--

CREATE SEQUENCE public.dashboard_course_student_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dashboard_course_student_groups_id_seq OWNER TO kalu;

--
-- Name: dashboard_course_student_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kalu
--

ALTER SEQUENCE public.dashboard_course_student_groups_id_seq OWNED BY public.dashboard_course_student_groups.id;


--
-- Name: dashboard_image; Type: TABLE; Schema: public; Owner: kalu
--

CREATE TABLE public.dashboard_image (
    id integer NOT NULL,
    name character varying(80),
    "timestamp" timestamp with time zone NOT NULL,
    updated timestamp with time zone,
    image character varying(100)
);


ALTER TABLE public.dashboard_image OWNER TO kalu;

--
-- Name: dashboard_image_id_seq; Type: SEQUENCE; Schema: public; Owner: kalu
--

CREATE SEQUENCE public.dashboard_image_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dashboard_image_id_seq OWNER TO kalu;

--
-- Name: dashboard_image_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kalu
--

ALTER SEQUENCE public.dashboard_image_id_seq OWNED BY public.dashboard_image.id;


--
-- Name: dashboard_studentgroup; Type: TABLE; Schema: public; Owner: kalu
--

CREATE TABLE public.dashboard_studentgroup (
    id integer NOT NULL,
    name character varying(80),
    "timestamp" timestamp with time zone NOT NULL,
    updated timestamp with time zone,
    gradebook_link character varying(160)
);


ALTER TABLE public.dashboard_studentgroup OWNER TO kalu;

--
-- Name: dashboard_studentgroup_banzhuren; Type: TABLE; Schema: public; Owner: kalu
--

CREATE TABLE public.dashboard_studentgroup_banzhuren (
    id integer NOT NULL,
    studentgroup_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.dashboard_studentgroup_banzhuren OWNER TO kalu;

--
-- Name: dashboard_studentgroup_banzhuren_id_seq; Type: SEQUENCE; Schema: public; Owner: kalu
--

CREATE SEQUENCE public.dashboard_studentgroup_banzhuren_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dashboard_studentgroup_banzhuren_id_seq OWNER TO kalu;

--
-- Name: dashboard_studentgroup_banzhuren_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kalu
--

ALTER SEQUENCE public.dashboard_studentgroup_banzhuren_id_seq OWNED BY public.dashboard_studentgroup_banzhuren.id;


--
-- Name: dashboard_studentgroup_id_seq; Type: SEQUENCE; Schema: public; Owner: kalu
--

CREATE SEQUENCE public.dashboard_studentgroup_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dashboard_studentgroup_id_seq OWNER TO kalu;

--
-- Name: dashboard_studentgroup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kalu
--

ALTER SEQUENCE public.dashboard_studentgroup_id_seq OWNED BY public.dashboard_studentgroup.id;


--
-- Name: dashboard_studentgroup_students; Type: TABLE; Schema: public; Owner: kalu
--

CREATE TABLE public.dashboard_studentgroup_students (
    id integer NOT NULL,
    studentgroup_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.dashboard_studentgroup_students OWNER TO kalu;

--
-- Name: dashboard_studentgroup_students_id_seq; Type: SEQUENCE; Schema: public; Owner: kalu
--

CREATE SEQUENCE public.dashboard_studentgroup_students_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dashboard_studentgroup_students_id_seq OWNER TO kalu;

--
-- Name: dashboard_studentgroup_students_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kalu
--

ALTER SEQUENCE public.dashboard_studentgroup_students_id_seq OWNED BY public.dashboard_studentgroup_students.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: kalu
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO kalu;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: kalu
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO kalu;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kalu
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: kalu
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO kalu;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: kalu
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO kalu;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kalu
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: kalu
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO kalu;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: kalu
--

CREATE SEQUENCE public.django_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO kalu;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kalu
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: kalu
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO kalu;

--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: auth_user id; Type: DEFAULT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.auth_user ALTER COLUMN id SET DEFAULT nextval('public.auth_user_id_seq'::regclass);


--
-- Name: auth_user_groups id; Type: DEFAULT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.auth_user_groups ALTER COLUMN id SET DEFAULT nextval('public.auth_user_groups_id_seq'::regclass);


--
-- Name: auth_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_user_user_permissions_id_seq'::regclass);


--
-- Name: dashboard_course id; Type: DEFAULT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.dashboard_course ALTER COLUMN id SET DEFAULT nextval('public.dashboard_course_id_seq'::regclass);


--
-- Name: dashboard_course_student_groups id; Type: DEFAULT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.dashboard_course_student_groups ALTER COLUMN id SET DEFAULT nextval('public.dashboard_course_student_groups_id_seq'::regclass);


--
-- Name: dashboard_image id; Type: DEFAULT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.dashboard_image ALTER COLUMN id SET DEFAULT nextval('public.dashboard_image_id_seq'::regclass);


--
-- Name: dashboard_studentgroup id; Type: DEFAULT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.dashboard_studentgroup ALTER COLUMN id SET DEFAULT nextval('public.dashboard_studentgroup_id_seq'::regclass);


--
-- Name: dashboard_studentgroup_banzhuren id; Type: DEFAULT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.dashboard_studentgroup_banzhuren ALTER COLUMN id SET DEFAULT nextval('public.dashboard_studentgroup_banzhuren_id_seq'::regclass);


--
-- Name: dashboard_studentgroup_students id; Type: DEFAULT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.dashboard_studentgroup_students ALTER COLUMN id SET DEFAULT nextval('public.dashboard_studentgroup_students_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: kalu
--

COPY public.auth_group (id, name) FROM stdin;
\.
COPY public.auth_group (id, name) FROM '$$PATH$$/2616.dat';

--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: kalu
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.
COPY public.auth_group_permissions (id, group_id, permission_id) FROM '$$PATH$$/2618.dat';

--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: kalu
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
\.
COPY public.auth_permission (id, name, content_type_id, codename) FROM '$$PATH$$/2614.dat';

--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: kalu
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
\.
COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM '$$PATH$$/2620.dat';

--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: kalu
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
\.
COPY public.auth_user_groups (id, user_id, group_id) FROM '$$PATH$$/2622.dat';

--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: kalu
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.
COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM '$$PATH$$/2624.dat';

--
-- Data for Name: dashboard_course; Type: TABLE DATA; Schema: public; Owner: kalu
--

COPY public.dashboard_course (id, name, "timestamp", updated, slug, image_id, description, brief_description, tagline) FROM stdin;
\.
COPY public.dashboard_course (id, name, "timestamp", updated, slug, image_id, description, brief_description, tagline) FROM '$$PATH$$/2630.dat';

--
-- Data for Name: dashboard_course_student_groups; Type: TABLE DATA; Schema: public; Owner: kalu
--

COPY public.dashboard_course_student_groups (id, course_id, studentgroup_id) FROM stdin;
\.
COPY public.dashboard_course_student_groups (id, course_id, studentgroup_id) FROM '$$PATH$$/2638.dat';

--
-- Data for Name: dashboard_image; Type: TABLE DATA; Schema: public; Owner: kalu
--

COPY public.dashboard_image (id, name, "timestamp", updated, image) FROM stdin;
\.
COPY public.dashboard_image (id, name, "timestamp", updated, image) FROM '$$PATH$$/2628.dat';

--
-- Data for Name: dashboard_studentgroup; Type: TABLE DATA; Schema: public; Owner: kalu
--

COPY public.dashboard_studentgroup (id, name, "timestamp", updated, gradebook_link) FROM stdin;
\.
COPY public.dashboard_studentgroup (id, name, "timestamp", updated, gradebook_link) FROM '$$PATH$$/2632.dat';

--
-- Data for Name: dashboard_studentgroup_banzhuren; Type: TABLE DATA; Schema: public; Owner: kalu
--

COPY public.dashboard_studentgroup_banzhuren (id, studentgroup_id, user_id) FROM stdin;
\.
COPY public.dashboard_studentgroup_banzhuren (id, studentgroup_id, user_id) FROM '$$PATH$$/2634.dat';

--
-- Data for Name: dashboard_studentgroup_students; Type: TABLE DATA; Schema: public; Owner: kalu
--

COPY public.dashboard_studentgroup_students (id, studentgroup_id, user_id) FROM stdin;
\.
COPY public.dashboard_studentgroup_students (id, studentgroup_id, user_id) FROM '$$PATH$$/2636.dat';

--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: kalu
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.
COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM '$$PATH$$/2626.dat';

--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: kalu
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
\.
COPY public.django_content_type (id, app_label, model) FROM '$$PATH$$/2612.dat';

--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: kalu
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
\.
COPY public.django_migrations (id, app, name, applied) FROM '$$PATH$$/2610.dat';

--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: kalu
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.
COPY public.django_session (session_key, session_data, expire_date) FROM '$$PATH$$/2639.dat';

--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kalu
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kalu
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kalu
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 27, true);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kalu
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kalu
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 1, true);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kalu
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Name: dashboard_course_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kalu
--

SELECT pg_catalog.setval('public.dashboard_course_id_seq', 4, true);


--
-- Name: dashboard_course_student_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kalu
--

SELECT pg_catalog.setval('public.dashboard_course_student_groups_id_seq', 1, false);


--
-- Name: dashboard_image_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kalu
--

SELECT pg_catalog.setval('public.dashboard_image_id_seq', 1, false);


--
-- Name: dashboard_studentgroup_banzhuren_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kalu
--

SELECT pg_catalog.setval('public.dashboard_studentgroup_banzhuren_id_seq', 1, false);


--
-- Name: dashboard_studentgroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kalu
--

SELECT pg_catalog.setval('public.dashboard_studentgroup_id_seq', 1, false);


--
-- Name: dashboard_studentgroup_students_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kalu
--

SELECT pg_catalog.setval('public.dashboard_studentgroup_students_id_seq', 1, false);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kalu
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 6, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kalu
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 9, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kalu
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 18, true);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: dashboard_course dashboard_course_pkey; Type: CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.dashboard_course
    ADD CONSTRAINT dashboard_course_pkey PRIMARY KEY (id);


--
-- Name: dashboard_course_student_groups dashboard_course_student_course_id_studentgroup_i_eca8ef8c_uniq; Type: CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.dashboard_course_student_groups
    ADD CONSTRAINT dashboard_course_student_course_id_studentgroup_i_eca8ef8c_uniq UNIQUE (course_id, studentgroup_id);


--
-- Name: dashboard_course_student_groups dashboard_course_student_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.dashboard_course_student_groups
    ADD CONSTRAINT dashboard_course_student_groups_pkey PRIMARY KEY (id);


--
-- Name: dashboard_image dashboard_image_pkey; Type: CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.dashboard_image
    ADD CONSTRAINT dashboard_image_pkey PRIMARY KEY (id);


--
-- Name: dashboard_studentgroup_banzhuren dashboard_studentgroup_b_studentgroup_id_user_id_531c24a4_uniq; Type: CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.dashboard_studentgroup_banzhuren
    ADD CONSTRAINT dashboard_studentgroup_b_studentgroup_id_user_id_531c24a4_uniq UNIQUE (studentgroup_id, user_id);


--
-- Name: dashboard_studentgroup_banzhuren dashboard_studentgroup_banzhuren_pkey; Type: CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.dashboard_studentgroup_banzhuren
    ADD CONSTRAINT dashboard_studentgroup_banzhuren_pkey PRIMARY KEY (id);


--
-- Name: dashboard_studentgroup dashboard_studentgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.dashboard_studentgroup
    ADD CONSTRAINT dashboard_studentgroup_pkey PRIMARY KEY (id);


--
-- Name: dashboard_studentgroup_students dashboard_studentgroup_s_studentgroup_id_user_id_2ae3b5cf_uniq; Type: CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.dashboard_studentgroup_students
    ADD CONSTRAINT dashboard_studentgroup_s_studentgroup_id_user_id_2ae3b5cf_uniq UNIQUE (studentgroup_id, user_id);


--
-- Name: dashboard_studentgroup_students dashboard_studentgroup_students_pkey; Type: CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.dashboard_studentgroup_students
    ADD CONSTRAINT dashboard_studentgroup_students_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: kalu
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: kalu
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: kalu
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: kalu
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: kalu
--

CREATE INDEX auth_user_groups_group_id_97559544 ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: kalu
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: kalu
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: kalu
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: kalu
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- Name: dashboard_course_image_id_a15425c4; Type: INDEX; Schema: public; Owner: kalu
--

CREATE INDEX dashboard_course_image_id_a15425c4 ON public.dashboard_course USING btree (image_id);


--
-- Name: dashboard_course_slug_8f677be8; Type: INDEX; Schema: public; Owner: kalu
--

CREATE INDEX dashboard_course_slug_8f677be8 ON public.dashboard_course USING btree (slug);


--
-- Name: dashboard_course_slug_8f677be8_like; Type: INDEX; Schema: public; Owner: kalu
--

CREATE INDEX dashboard_course_slug_8f677be8_like ON public.dashboard_course USING btree (slug varchar_pattern_ops);


--
-- Name: dashboard_course_student_groups_course_id_684fe305; Type: INDEX; Schema: public; Owner: kalu
--

CREATE INDEX dashboard_course_student_groups_course_id_684fe305 ON public.dashboard_course_student_groups USING btree (course_id);


--
-- Name: dashboard_course_student_groups_studentgroup_id_522ba68f; Type: INDEX; Schema: public; Owner: kalu
--

CREATE INDEX dashboard_course_student_groups_studentgroup_id_522ba68f ON public.dashboard_course_student_groups USING btree (studentgroup_id);


--
-- Name: dashboard_studentgroup_banzhuren_studentgroup_id_1fd4f0ae; Type: INDEX; Schema: public; Owner: kalu
--

CREATE INDEX dashboard_studentgroup_banzhuren_studentgroup_id_1fd4f0ae ON public.dashboard_studentgroup_banzhuren USING btree (studentgroup_id);


--
-- Name: dashboard_studentgroup_banzhuren_user_id_8f7a0f47; Type: INDEX; Schema: public; Owner: kalu
--

CREATE INDEX dashboard_studentgroup_banzhuren_user_id_8f7a0f47 ON public.dashboard_studentgroup_banzhuren USING btree (user_id);


--
-- Name: dashboard_studentgroup_students_studentgroup_id_2ba55a3e; Type: INDEX; Schema: public; Owner: kalu
--

CREATE INDEX dashboard_studentgroup_students_studentgroup_id_2ba55a3e ON public.dashboard_studentgroup_students USING btree (studentgroup_id);


--
-- Name: dashboard_studentgroup_students_user_id_be02ef48; Type: INDEX; Schema: public; Owner: kalu
--

CREATE INDEX dashboard_studentgroup_students_user_id_be02ef48 ON public.dashboard_studentgroup_students USING btree (user_id);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: kalu
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: kalu
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: kalu
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: kalu
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dashboard_course dashboard_course_image_id_a15425c4_fk_dashboard_image_id; Type: FK CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.dashboard_course
    ADD CONSTRAINT dashboard_course_image_id_a15425c4_fk_dashboard_image_id FOREIGN KEY (image_id) REFERENCES public.dashboard_image(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dashboard_course_student_groups dashboard_course_stu_course_id_684fe305_fk_dashboard; Type: FK CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.dashboard_course_student_groups
    ADD CONSTRAINT dashboard_course_stu_course_id_684fe305_fk_dashboard FOREIGN KEY (course_id) REFERENCES public.dashboard_course(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dashboard_course_student_groups dashboard_course_stu_studentgroup_id_522ba68f_fk_dashboard; Type: FK CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.dashboard_course_student_groups
    ADD CONSTRAINT dashboard_course_stu_studentgroup_id_522ba68f_fk_dashboard FOREIGN KEY (studentgroup_id) REFERENCES public.dashboard_studentgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dashboard_studentgroup_banzhuren dashboard_studentgro_studentgroup_id_1fd4f0ae_fk_dashboard; Type: FK CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.dashboard_studentgroup_banzhuren
    ADD CONSTRAINT dashboard_studentgro_studentgroup_id_1fd4f0ae_fk_dashboard FOREIGN KEY (studentgroup_id) REFERENCES public.dashboard_studentgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dashboard_studentgroup_students dashboard_studentgro_studentgroup_id_2ba55a3e_fk_dashboard; Type: FK CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.dashboard_studentgroup_students
    ADD CONSTRAINT dashboard_studentgro_studentgroup_id_2ba55a3e_fk_dashboard FOREIGN KEY (studentgroup_id) REFERENCES public.dashboard_studentgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dashboard_studentgroup_banzhuren dashboard_studentgro_user_id_8f7a0f47_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.dashboard_studentgroup_banzhuren
    ADD CONSTRAINT dashboard_studentgro_user_id_8f7a0f47_fk_auth_user FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dashboard_studentgroup_students dashboard_studentgro_user_id_be02ef48_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.dashboard_studentgroup_students
    ADD CONSTRAINT dashboard_studentgro_user_id_be02ef48_fk_auth_user FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk; Type: FK CONSTRAINT; Schema: public; Owner: kalu
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

